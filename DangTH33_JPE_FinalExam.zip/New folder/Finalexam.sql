USE master;
GO
IF DB_ID('BookStore') IS NOT NULL 
DROP DATABASE BookStore
GO 
CREATE DATABASE BookStore;
GO 
USE BookStore;
GO 

CREATE TABLE Books(
    bookId		INT  PRIMARY KEY ,
    title		VARCHAR (150),
    author		VARCHAR(100),
    price		DECIMAL,
    quantity	INT 
);

GO

INSERT INTO Books(bookId,title,author,price,quantity)
VALUES      (1001,'Java SE Programing Essentials','Steven Jobs',11.11,11),
            (1002,'Learning SQL','Bill Gates',22.22,22),
            (1003,'Servlet and JSP','Elon Musk',33.33,33),
            (1004,'Pro Angular 8','James Gosling',88.88,8),
            (1005,'Mastering Node.js','Larry Page',55.55,5)