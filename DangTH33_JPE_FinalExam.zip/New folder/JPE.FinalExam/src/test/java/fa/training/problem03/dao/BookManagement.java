package fa.training.problem03.dao;

import fa.training.problem03.models.Books;

import java.util.Scanner;

import static java.lang.Integer.parseInt;

public class BookManagement {


    public Books createNewBook(){
        Books book = new Books();
        Scanner sc = new Scanner(System.in);
            System.out.println("Enter bookId: ");
            book.setBookId(parseInt(sc.nextLine()));

            System.out.println("Enter book's title: ");
            book.setTitle(String.valueOf(sc.nextLine()));

            System.out.println("Enter book's author: ");
            book.setAuthor(sc.nextLine());



            System.out.println("Enter book's price: ");
            book.setPrice(sc.nextDouble());



            System.out.println("Enter quantity: ");
            book.setQuantity(sc.nextInt());

        return book;
    }
}
