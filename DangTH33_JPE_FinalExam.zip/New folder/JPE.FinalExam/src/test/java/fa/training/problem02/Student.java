package fa.training.problem02;

import java.io.Serializable;

public class Student implements Serializable {
    private int studentId;
    private String studentName;
    private String skill;

    public Student() {
    }

    public Student(int studentId, String studentName, String skill) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.skill = skill;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                ", skill='" + skill + '\'' +
                '}';
    }
}
