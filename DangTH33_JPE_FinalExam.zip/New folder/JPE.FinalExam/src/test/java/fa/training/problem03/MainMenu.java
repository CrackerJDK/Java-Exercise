package fa.training.problem03;

import fa.training.problem03.dao.BookDao;
import fa.training.problem03.dao.BookManagement;
import fa.training.problem03.models.Books;

import java.util.Scanner;

public class MainMenu {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BookDao bookDao = new BookDao();
        BookManagement book = new BookManagement();
        int key;
        do {
            System.out.println("        =====Management System=====");
            System.out.println("System message: choose function that you want");
            System.out.println(" 1. Create a new book");
            System.out.println(" 2. Update book");
            System.out.println(" 3. Display book list");
            key = sc.nextInt();
            switch (key) {
                case 1:

                    Books book1 = book.createNewBook();
                    bookDao.save(book1);
                    break;
                case 2:
                    Books book2 = book.createNewBook();
                    bookDao.update(book2);
                    break;
                case 3:
                    System.out.println("Get Book List: ");
                    System.out.println(bookDao.getBookList());
                    break;
                case 4:
                    break;
            }
        }while (key!=4);

}
}

