package fa.training.problem01;

import java.util.Scanner;

public class Problem01 {
    public static void main(String[] args) {
        Problem01 problem01 = new Problem01();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number you want to check: ");
        Integer inputValue = sc.nextInt();
        problem01.fizzBuzz(inputValue);
        System.out.println(problem01.fizzBuzz(inputValue));
    }
     public String fizzBuzz(Integer inputValue)
     {

         if((inputValue%5==0) && (inputValue%3==0))
             return "FizzBuzz";
         else if(inputValue%3==0)
             return "Fizz";
         else if(inputValue%5==0)
             return "Buzz";
         else
         {
             return String.valueOf(inputValue);
         }
     }
}
