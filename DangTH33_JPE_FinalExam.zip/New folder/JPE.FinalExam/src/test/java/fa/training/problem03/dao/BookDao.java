package fa.training.problem03.dao;

import fa.training.problem03.DatabaseConnection;
import fa.training.problem03.models.Books;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDao implements BookImpl{


    @Override
    public boolean save(Books book) {

        try (Connection connection = DatabaseConnection.getConnection()) {
            String sqlQuery= "INSERT INTO Books (bookId,title,author,price,quantity) VALUES (?,?,?,?,?);";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1,book.getBookId());
            preparedStatement.setString(2,book.getTitle());
            preparedStatement.setString(3, book.getAuthor());
            preparedStatement.setDouble(4,book.getPrice());
            preparedStatement.setInt(5,book.getQuantity());
            System.out.println("Successful!");
            return  preparedStatement.executeUpdate() >0;

        } catch (SQLException throwables) {
            System.out.println("Failed!");
            throwables.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean update(Books book) {
        try(Connection connection = DatabaseConnection.getConnection())
        {
            String sqlQuery = "UPDATE Books SET bookId = ?, title = ?, author = ?, price = ?, quantity = ? WHERE bookId = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);

            preparedStatement.setString(1,book.getTitle());
            preparedStatement.setString(2, book.getAuthor());
            preparedStatement.setDouble(3,book.getPrice());
            preparedStatement.setInt(4,book.getQuantity());
            preparedStatement.setInt(5, book.getBookId());
            System.out.println("Update success!");
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("Update failed");
        }
        return false;
    }

    @Override
    public List<Books> getBookList() {
        List<Books> bookList = new ArrayList<>();
        //step 1 :Create  connection
        try(Connection connection = DatabaseConnection.getConnection())
        {
            String sqlQuery = "SELECT bookId,title,author,price,quantity FROM Books;";
            // step 2 : create Statement
            PreparedStatement statement = connection.prepareStatement(sqlQuery);
            //step 3: Get data from ResultSet
            ResultSet rs = statement.executeQuery();
            while (rs.next()){
                int bookId = rs.getInt(1);
                String title = rs.getString(2);
                String author = rs.getString(3);
                double price = rs.getDouble(4);
                int quantity = rs.getInt(5);
                bookList.add(new Books(bookId,title,author,price,quantity));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bookList;
    }
}
