package fa.training.problem03.dao;

import fa.training.problem03.models.Books;
import java.util.List;

public interface BookImpl {
    boolean save(Books book);
    boolean update(Books book);
    List<Books> getBookList();
}
