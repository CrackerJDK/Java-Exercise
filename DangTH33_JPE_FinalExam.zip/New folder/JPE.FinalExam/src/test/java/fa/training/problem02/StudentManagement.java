package fa.training.problem02;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class StudentManagement {

    public List<Student> printList() throws IOException, ClassNotFoundException {
        File file = new File("D:\\JAVA COURSE\\JPE.FinalExam\\src\\main\\resources\\course_register.txt");
        List<Student> studentList = readFile(file);
        System.out.println(studentList);
        return studentList;
    }

    public List<Student> readFile(File file) throws IOException, ClassNotFoundException {
        List<Student> studentList = new ArrayList<>();
        try(ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(String.valueOf(file))))){
            while (true) {
                Object object = ois.readObject();
                if(object instanceof Student) {
                    studentList.add((Student) object);
                }
            }
        }
        catch (EOFException eo)
        {
            eo.getStackTrace();
        }
        return studentList;
    }

    public File addToFile(List<Student> studentList) throws IOException {
        File file = new File("D:\\JAVA COURSE\\JPE.FinalExam\\src\\main\\resources\\course_register.txt");
        boolean check = writeStudentToFile(file, studentList);
        if(!check){
            System.out.println("The data has been loaded into file!");
        }
        else
            System.out.println("Loading failed!");
        return file;
    }

    public static boolean writeStudentToFile(File file, List<Student> studentList) throws IOException {
        boolean check = false;
        try (ObjectOutputStream ois = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)))){
            for (Student student: studentList)
            {
                ois.writeObject(student);
                check = true;
            }
        }
        if(!check)
        {
            return true;
        }
        return false;
    }
}
