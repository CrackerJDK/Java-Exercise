package fa.training.problem02;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CourseRegister {
    public static StudentManagement studentManagement = new StudentManagement();

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        List<Student> studentList = new ArrayList<>();
        studentList.add(new Student(1001,"Pham Van A", "C++"));
        studentList.add(new Student(1002, "Pham Van B", "C#"));
        studentList.add(new Student(1003, "Pham Van C", "JAVA"));
        studentList.add(new Student(1004, "Pham Van D", "JavaScript"));
        studentList.add(new Student(1002, "Pham Van E", "GoLang"));
        // thêm list vào file
        studentManagement.addToFile(studentList);
        // đọc file
        studentManagement.readFile(studentManagement.addToFile(studentList));
        // in ra list
        studentManagement.printList();

    }
}
