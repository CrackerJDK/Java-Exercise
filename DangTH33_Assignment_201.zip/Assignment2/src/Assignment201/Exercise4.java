package Assignment201;

import java.lang.Math;
import java.util.Scanner;

public class Exercise4 {
    public static void main(String[] args) {
        Scanner Input3 = new Scanner(System.in);
        System.out.println("Enter radius value: ");
        float radius = Input3.nextFloat();
        System.out.println("Enter height value: ");
        float height = Input3.nextFloat();
        float surfaceArea, baseArea, volume;
        System.out.println("Surface area = "+(2*radius*(radius+height)*Math.PI));
        System.out.println("Base area = "+(Math.pow(radius,2)*Math.PI));
        System.out.println("Volume = "+(Math.pow(radius,2)*Math.PI)*height);
    }
}
