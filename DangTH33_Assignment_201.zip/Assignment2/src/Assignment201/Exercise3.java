package Assignment201;

import java.util.Scanner;

public class Exercise3 {
    public static void main(String[] args) {

        Scanner Input2 = new Scanner(System.in);

        System.out.printf("Input first number: ");
        int num1 = Input2.nextInt();
        System.out.printf("Input second number: ");
        int num2 = Input2.nextInt();
        System.out.printf("Input third number: ");
        int num3 = Input2.nextInt();
        System.out.printf("Input fourth number: ");
        int num4 = Input2.nextInt();
        System.out.printf("Input fifth number: ");
        int num5 = Input2.nextInt();

        System.out.printf("The sum is: " + (num1 + num2 + num3 + num4 + num5));
    }
}
