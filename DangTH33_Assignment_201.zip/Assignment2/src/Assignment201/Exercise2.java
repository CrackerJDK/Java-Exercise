package Assignment201;

import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {

        Scanner Input = new Scanner(System.in);

        System.out.printf("Input first number: ");
        int num1 = Input.nextInt();
        System.out.printf("Input second number: ");
        int num2 = Input.nextInt();
        System.out.printf("Input third number: ");
        int num3 = Input.nextInt();
        System.out.printf("Input fourth number: ");
        int num4 = Input.nextInt();

        if((num1!=num2) && (num1!=num3) && (num1!=num4) && (num2!=num3) && (num2!=num4) && (num3!=num4))
        {
            System.out.printf("Numbers are not equal!");
        }

        else
        {
            System.out.printf("In four numbers, there are equal numbers!");
        }
    }
}
