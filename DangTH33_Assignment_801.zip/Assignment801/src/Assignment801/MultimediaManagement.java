package Assignment801;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MultimediaManagement {
    List<Multimedia> listOfMultimedia = new ArrayList<>();
    Scanner sc = new Scanner(System.in);
    int optionalNumber;
    String name;
    double duration;
    String singer;



    public void addMultiMedia() {

        do {
            System.out.println("Choose function");
            System.out.println("1. Add a new video");
            System.out.println("2. Add a new song");
            System.out.println("3. Show all multimedia");
            System.out.println("4. Exit");
            System.out.println("Your choice: ");
            optionalNumber = sc.nextInt(); //Integer.parseInt(sc.nextLine());
            sc.nextLine();
            if (optionalNumber == 1)
            {

                System.out.println("Enter video name: ");
                name = sc.nextLine();
                System.out.println("Enter duration: ");
                duration = sc.nextDouble();

                listOfMultimedia.add(new Video(name,duration));
            }

            if (optionalNumber == 2)
            {
                System.out.println("Enter singer name: ");
                singer = sc.nextLine();
                System.out.println("Enter song name: ");
                name = sc.nextLine();
                System.out.println("Enter duration: ");
                duration = sc.nextDouble();

                listOfMultimedia.add(new Song(name,duration,singer));
            }

            if (optionalNumber == 3)
            {
                displayMultiMedia();
            }

            if (optionalNumber == 4) {
                System.out.println("System message: Good Bye!");
                break;
            }
            if ((optionalNumber<=0) || (optionalNumber>4))
            {System.out.println("System alert: The key you have just pressed is not valid. Let's choose form 1 to 4!");}
        }while (optionalNumber<4 && optionalNumber>0);
    }

    public void displayMultiMedia() {
        for (Multimedia list: listOfMultimedia){
            System.out.println(list);
        }
    }

    public void availableMultimedia() {
        listOfMultimedia.add(new Song("Sing me to sleep", 3.35D, "Alan Walker"));
        listOfMultimedia.add(new Song("Lily", 3.16D, "Alan Walker, K-391 & Emelie Hollow"));
        listOfMultimedia.add(new Song("Way back home", 3.35D, "SHAUN feat. Conor Maynard"));
        listOfMultimedia.add(new Song("Memories", 3.15D, "Maroon 5"));
        listOfMultimedia.add(new Song("Unravel - Tokyo Ghoul", 4.24D, "TK"));
        listOfMultimedia.add(new Song("Hey Brother", 4.45D, "Avicii"));
        listOfMultimedia.add(new Song("Dynasty", 4.44D, "MIIA"));
        listOfMultimedia.add(new Song("Titanium", 4.05D, "David Guetta"));

        listOfMultimedia.add(new Video("Batman v Superman", 180.5D));
        listOfMultimedia.add(new Video("Your name", 120.56D));
        listOfMultimedia.add(new Video("V for vendetta", 180.5D));
        listOfMultimedia.add(new Video("National Geographic", 60.5D));
        listOfMultimedia.add(new Video("Discovery Chanel", 30.5D));
        listOfMultimedia.add(new Video("CNN Breaking News", 20.5D));

    }


}
