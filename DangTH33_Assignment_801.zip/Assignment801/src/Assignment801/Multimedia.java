package Assignment801;

import java.util.Scanner;

public abstract class Multimedia {
    private String name;
    private double duration;

    public Multimedia() {
    }

    public Multimedia(String name, double duration) {
        this.name = name;
        this.duration = duration;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public void createMultimedia(){
        Scanner input1 = new Scanner(System.in);
        System.out.println("Enter name's song/video: ");
        name = input1.nextLine();
        System.out.println("Enter the duration: ");
        duration = input1.nextDouble();
    }

    public void menu() {

    }

    @Override
    public String toString() {
        return "name: " + name + '\'' +
                ", duration: " + duration;
    }
}
