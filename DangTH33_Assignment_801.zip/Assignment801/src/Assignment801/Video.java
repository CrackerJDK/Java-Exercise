package Assignment801;

public class Video extends Multimedia{

    public Video(String name, double duration) {
        super(name, duration);
    }

    public void createVideo() {
        createMultimedia();

    }

    @Override
    public String toString() {
        return "Video {" + super.toString() + "} ";
    }
}
