package Assignment801;

import java.util.Scanner;

public class Song extends Multimedia{
    private String singer;

    public Song() {

    }

    public Song(String name, double duration,String singer) {
        super(name, duration);
        this.singer = singer;
    }

    public String getSinger() {
        return singer;
    }

    public void setSinger(String singer) {
        this.singer = singer;
    }

    public void createSong()
    {
        createMultimedia();
        Scanner input2 = new Scanner(System.in);
        System.out.println("Enter the name of the singer: ");
        singer = input2.nextLine();
    }

    @Override
    public String toString() {
        return "Song {" + super.toString() +
                ", singer: " + singer + '\'' +
                "} ";
    }
}



