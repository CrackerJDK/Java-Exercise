package com.company;

import Assignment801.Multimedia;
import Assignment801.MultimediaManagement;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        MultimediaManagement execution = new MultimediaManagement();
        execution.availableMultimedia();
        execution.addMultiMedia();
    }
}