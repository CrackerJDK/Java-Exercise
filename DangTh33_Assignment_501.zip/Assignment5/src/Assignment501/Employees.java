package Assignment501;

public class Employees {
    private String courseId;
    private  String name;
    private  double duration;
    private  String status;
    private  String flag;

    public Employees() {
    }

    public Employees(String courseId, String name, double duration, String status, String flag) {
        this.courseId = courseId;
        this.name = name;
        this.duration = duration;
        this.status = status;
        this.flag = flag;
    }

    public String getCourseId() {
        return courseId;
    }

    public String getName() {
        return name;
    }

    public double getDuration() {
        return duration;
    }

    public String getStatus() {
        return status;
    }

    public String getFlag() {
        return flag;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "Employee"+": "+
                "courseId="+courseId +"\t" +
                ",name="+name +"\t" +
                ",duration="+duration +"\t" +
                ",status="+status +"\t" +
                ",flag="+flag + "\t";
    }
}
