package Assignment501;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class EmployeeManager {

    ArrayList<Employees> employees = new ArrayList<>();
    ArrayList<String> courseID= new ArrayList<>();

    Scanner sc= new Scanner(System.in);

    /**
     * User input data
     * @param_scanner
     */
    private   void addAssigmentMenu(){
        String courseId = null;
        String flag=null;
        String status=null;
        boolean check;
        do{

            check = false;
            System.out.println("Enter Course:(Format start FW folow 3 digit) ");
            courseId= sc.nextLine().trim();
            check=Validator.isCourse(courseId)&& ! courseID.contains(courseId);
            //  System.out.println(check);
        }while (!check);
        System.out.println(" Enter Name: ");
        String name= sc.nextLine();
        System.out.println(" Enter Duration");
        double duration= Double.parseDouble(sc.nextLine());
        do{
            check = false;
            System.out.println(" Enter status (active or in-active)");
            try{
                status= sc.nextLine();
                check=(Validator.isActive(status));
                //    System.out.println(check);
            }catch (Exception exception){
                check= false;
            }
            //dk dưng check = true.
        }while (!check);
        do{
            check= false;
            System.out.println("Enter flag :(optional,mandatory,N/A) ");
            try {
                flag =sc.nextLine();
                check=(Validator.isFlag(flag));
                // System.out.println(check);
            }catch (Exception exception){
                check= false;
            }
        }while (!check);
        employees.add(new Employees(courseId,name,duration,status,flag));
        courseID.add(courseId);
    }


    private  void searchByCourseID(){
        System.out.println("Enter keyword : ");
        String keyword= sc.nextLine();
        for(Employees employees : this.employees){
            if(employees.getCourseId().equals(keyword)){
                System.out.println(employees);
            }
        }
    }

    private void sortByCourseID(){
        Collections.sort(employees, new Comparator<Employees>() {
            @Override
            public int compare(Employees o1, Employees o2) {
                return o1.getCourseId().compareTo(o2.getCourseId());
            }
        });
        display();
    }

    private void display(){
        System.out.println("List Assigment: ");
        for(Employees employees : this.employees){
            System.out.println(employees);
        }
    }


    private Employees getAssigment(){
        System.out.println("Enter codeCourse ");
        String course= sc.nextLine();
        for(Employees employees : this.employees){
            if(employees.getCourseId().equals(course)){
                return employees;
            }
        }
        return  null;
    }


    private  void removeByCode(Employees employees){
        this.employees.remove(employees);
    }


    public  void menu(){
        innit();
        int userChoice;
        do{
            System.out.println("1. Add Assigment");
            System.out.println("2. Display Assigment");
            System.out.println("3. Search By CourseID");
            System.out.println("4 .Delete");
            System.out.println("5. Sort by courseID ");
            System.out.println("0. Exiting......");
            userChoice =sc.nextInt();
            sc.nextLine();
            switch (userChoice){
                case 1: {addAssigmentMenu();}
                case 2: display();
                case 3: searchByCourseID();
                case 4: {
                    Employees employees = getAssigment();
                    removeByCode(employees);
                }
                case 5: sortByCourseID();
                case 0: System.exit(0);
            }
        }while (userChoice!=0);
    }
//     courseId,name,duration,status,flag

    private  void innit(){
        employees.add(new Employees("FW001","Jonh",25,"active","N/A"));
        employees.add(new Employees("FW002","Mark",25,"active","mandatory"));
        employees.add(new Employees("FW003","Tim",25,"in-active","N/A"));
        employees.add(new Employees("FW004","Tom",25,"in-active","N/A"));
        courseID.add("FW001");
        courseID.add("FW002");
        courseID.add("FW003");
        courseID.add("FW004");
    }

}
