package Assignment501;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
    private static final String VALID_COURSE_REGEX = "^FW+[0-9]{3}$";

    public static boolean isCourse(String codeCourse) {
        Pattern pattern = Pattern.compile(VALID_COURSE_REGEX);
        Matcher matcher = pattern.matcher(codeCourse);
        return matcher.matches();
    }
    public  static  boolean isActive(String status){
        if((status.equals("active"))|| (status.equals("in-active"))){
            return  true;
        }
        return  false;
    }
    public  static  boolean isFlag(String flag){
        if ((flag.equals("optional"))||(flag.equals("mandatory"))||(flag.equals("N/A"))){
            return  true;
        }
        return  false;
    }
}
