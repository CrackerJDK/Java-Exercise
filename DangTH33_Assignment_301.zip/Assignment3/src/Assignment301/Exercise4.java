package Assignment301;

public class Exercise4 {
    public static void main(String[] args) {
        int[] myIntArray = { 43, 32, 53, 23, 12, 34, 3, 12, 43, 32 };
        int i;
        int n = myIntArray.length;
        int temp;
        System.out.printf("" + n/2);
        for (i=0; i < (n - 1) / 2; ++i)
        {
            temp = myIntArray[i];
            myIntArray[i] = myIntArray[n-1-i];
            myIntArray[n-1-i] = temp;
        }

        System.out.println("The array after reverse: \n");
        System.out.printf("{");
        for (i=0; i<n; i++)
        {
            System.out.printf(" " + myIntArray[i] + ",");
        }
        System.out.printf("}");
    }
}
