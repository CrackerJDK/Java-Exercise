package Assignment301;

import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {
        Scanner Input = new Scanner(System.in);

        System.out.printf("Enter length of array: ");
        int n = Input.nextInt();
        String [] array = new String[100];
        int i = 0;
        System.out.println("Enter the elements of the array: ");
        while (i<n)
        {
            array[i]=Input.next();
            i++;
        }

        for (i = 0; i < n; i++)
        {
            System.out.println(array[i]);
        }

        String str = (String) Check();

        for (i = 0; i < n; i++)
        {
            if (array[i].equals(str))
            {
                System.out.println("Check '" + str +"' in Array: Contained!");
                break;
            }
        }

        for (int j = 0; j < n; j++)
        {
            int count = 0;
            if (!array[j].equals(str))
            {
                count++;
                if(count==n)
                {
                    System.out.println("Not Contain!");
                }
            }


        }
    }

    public static Object Check() {
        Scanner Input = new Scanner(System.in);
        String check = Input.nextLine();
        return check;
    }

}
