package Assignment301;

public class Exercise1 {
    public static void main(String[] args) {
        float sumAverageRunningInt = 0.0F;
        for (int i = 1; i<= 100; i++)
        {
            sumAverageRunningInt += i;
        }

        System.out.println("Average of all 100 first numbers: "+ sumAverageRunningInt/100);
    }
}
