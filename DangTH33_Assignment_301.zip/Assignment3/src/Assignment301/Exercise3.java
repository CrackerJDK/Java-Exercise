package Assignment301;

import java.util.Scanner;

public class Exercise3 {
    public static void main(String[] args) {
        System.out.println("Enter the number of elements of the array: ");
        Scanner Input = new Scanner(System.in);
        int n = Input.nextInt();
        int [] a = new int[n];
        int i = 0, count1 = 0;
        char c;
        do
        {
            a[i] = Input.nextInt();

            System.out.println("Do you want to continue? Y/N? ");
            c = Input.next().charAt(0);
            i+=1;
            count1+=1;

            do
            {

                if (c != 'n' && c != 'N' && c != 'y' && c != 'Y')
                {
                    System.out.println("Warning: Please choose Y or N you cannot press any other key!");
                }

            } while (c != 'n' && c != 'N' && c != 'y' && c != 'Y');

        } while (c == 'y' || c == 'Y' || i < n);

        System.out.println("Enter the value you want to check: ");
        int value = Input.nextInt();
        int j, count2 = 0;
        for (j = 0; j < count1; j++)
        {
            if (value==a[j])
            {
                count2+=1;
            }
        }
        System.out.println("The number of occurrences of " + value + " is: " + count2);
    }
}
