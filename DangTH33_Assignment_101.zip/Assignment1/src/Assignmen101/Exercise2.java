package Assignmen101;
/*
125 + 24 = 149
125 - 24 = 101
125 x 24 = 3000
125 / 24 = 5
125 % 24 = 5
 */
public class Exercise2 {
    public static void main(String[] args) {
        int a = 125;
        int b = 24;
        System.out.println("125 + 24 = " + (a + b));
        System.out.println("125 - 24 = " + (a - b));
        System.out.println("125 x 24 = " + (a * b));
        System.out.println("125 / 24 = " + (a / b));
        System.out.println("125 % 24 = " + (a % b));
    }
}
