package Assignmen101;

import java.text.DecimalFormat;

public class Exercise6 {
    public static void main(String[] args) {
        float Width = 5.6F;
        float Height = 8.5F;
        // round to two second decimal places
        DecimalFormat df = new DecimalFormat("##.00");
        df.setMaximumFractionDigits(2);
        System.out.println("Area is 5.6 * 8.5 = "+df.format(Width*Height));
        System.out.println("Perimeter is 2 * (5.6 + 8.5) = "+df.format(2*(Width+Height)));

    }
}
