package Assignmen101;
import java.lang.Math;
public class Exercise5 {
    public static void main(String[] args) {
        float Radius = 7.5F;
        System.out.println("Perimeter is = "+(Radius*Math.PI));
        System.out.println("Area is = "+(Math.pow(Radius,2)*Math.PI));
    }
}
