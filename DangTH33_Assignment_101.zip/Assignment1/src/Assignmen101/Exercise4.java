package Assignmen101;
// Test data
public class Exercise4 {
    public static void main(String[] args) {
        System.out.println(((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5)));
    }
}
