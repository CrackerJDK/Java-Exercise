USE master
IF DB_ID('Assignment1001JAVA') IS NOT NULL 
DROP DATABASE Assignment1001JAVA 
GO
CREATE DATABASE Assignment1001JAVA
GO
USE Assignment1001JAVA
GO


CREATE TABLE Customer (
	customerId			INT PRIMARY KEY, 
	customerName		VARCHAR(150)
)

CREATE TABLE Employeee (
	employeeId			INT PRIMARY KEY, 
	employeeName		VARCHAR(150),
	salary				DECIMAL, 
	supervisorId		INT
)

CREATE TABLE Product (
	productId			INT PRIMARY KEY, 
	productName			VARCHAR(150), 
	listPrice			DECIMAL
)

CREATE TABLE Orders (
	orderId				INT PRIMARY KEY, 
	orderDate			DATE, 
	customerId			INT , 
	employeeId			INT ,	
	total				DECIMAL
)
CREATE TABLE LineItem (
	orderId				INT FOREIGN KEY REFERENCES Orders(orderId), 
	productId			INT FOREIGN KEY REFERENCES Product(productId), 
	quantity			INT	, 
	price				DECIMAL
)	
GO


INSERT INTO Customer(customerId,customerName)
VALUES
(1,'Cleopatra VII'),
(2,'Julius Caesar'),
(3,'Leonidas I')

GO

INSERT INTO Orders(orderId,orderDate,customerId,employeeId,total)
VALUES
(1,GETDATE(),1,1,3),
(2,GETDATE(),2,2,2),
(3,GETDATE(),3,3,3)


GO

INSERT INTO Product(productId,productName,listPrice)
VALUES
(1,'Xbox Console',799),
(2,'PS5 Console',499),
(3,'Dell PC Gaming',1499),
(4,'Nintendo Switch',299)

GO

INSERT INTO LineItem(orderId,productId,quantity,price)
VALUES
(1,1,3,799),
(2,1,3,499),
(3,2,3,299)


GO

INSERT INTO Employeee(employeeId,employeeName,salary,supervisorId)
VALUES
(1,'Saladin',20000,3),
(2,'BaldWind IV',15000,1),
(3,'King Clovis',25000,2)



GO


CREATE PROCEDURE InsertCustomer 
		@customerId			INT, 
		@customerName		VARCHAR(150)
AS 
BEGIN 

     INSERT INTO Customer
          (                    
            customerId,
			customerName        
          ) 
     VALUES 
          ( 
            @customerId,
            @customerName
          ) 
END 

GO


CREATE PROCEDURE DeleteCustomer
    (
		@customerId			INT
	)
AS 
BEGIN
    DELETE Customer  
    WHERE customerId = @customerId
END

GO

CREATE PROCEDURE UpdateCustomer
    (
		@customerId			INT,
		@customerName		VARCHAR(150)
	)
AS 
BEGIN
    UPDATE Customer  
	SET customerName=@customerName
    WHERE customerId = @customerId
END

GO

SELECT L.orderId, SUM(P.listPrice*L.quantity) AS totalPrice FROM Product P JOIN LineItem L ON L.productId = P.productId AND L.orderId=3 GROUP BY L.orderId

SELECT * FROM Customer
SELECT * FROM Orders WHERE orderId = 3
SELECT * FROM Employeee
SELECT * FROM Product
SELECT orderId,productId,quantity,price FROM LineItem WHERE orderId = 3