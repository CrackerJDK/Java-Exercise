package fa.training.services;

import fa.training.entity.Order;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class OrderService {
    static Scanner sc = new Scanner(System.in);
    public Order updateOrders(Order orders){

        boolean check = false;

        System.out.println("Do you want change order date? Y/N?");
        String answer = sc.next();
        if (answer.equalsIgnoreCase("Y")){
            do {
                check = false;
                System.out.println("Enter order date :");
                try {
                    String orderDate = sc.nextLine();
                    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate localDate = LocalDate.parse(orderDate, dateFormat);
                    orders.setOrderDate(localDate);
                }catch (Exception exception){
                    check = true;
                }
            }while (check);
        }

        System.out.println("Do you want update customerId?(Y/N)");
        answer = sc.next();
        if (answer.equalsIgnoreCase("Y")) {
            do {
                check = false;
                System.out.println("Enter the customerId update:");
                try {
                    orders.setCustomerId(Integer.parseInt(sc.next()));
                } catch (Exception exception) {
                    check = true;
                }
            } while (check);
        }

        System.out.println("Do you want update employeeId?(Y/N)");
        answer = sc.next();
        if (answer.equalsIgnoreCase("Y")) {
            do {
                check = false;
                System.out.println("Enter the employeeId update:");
                try {
                    orders.setEmployeeId(Integer.parseInt(sc.next()));
                } catch (Exception exception) {
                    check = true;
                }
            } while (check);
        }

        System.out.println("Do you want update total?(Y/N)");
        answer = sc.next();
        if (answer.equalsIgnoreCase("Y")) {
            do {
                check = false;
                System.out.println("Enter the total update:");
                try {
                    orders.setTotal(Integer.parseInt(sc.next()));
                } catch (Exception exception) {
                    check = true;
                }
            } while (check);
        }
        return orders;

    }

    public Order addOrder(Order orders){
        boolean check = false;
        do {
            check = false;
            System.out.println("Enter orderId: ");
            try {
                orders.setOrderId(sc.nextInt());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            try {
                System.out.println("Enter the orderDate: ");
                String orderDate=sc.nextLine();
                DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate orderDate1 = LocalDate.parse(orderDate,dateFormat);
                orders.setOrderDate(orderDate1);
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter the customerId: ");
            try {
                orders.setCustomerId(sc.nextInt());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter the employee_Id: ");
            try {
                orders.setEmployeeId(sc.nextInt());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter total: ");
            try {
                orders.setTotal(sc.nextDouble());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        return orders;
    }

}

