package fa.training.intefaces;

import fa.training.entity.Order;

import java.util.List;

public interface OrderDaoImp {
    List<Order> getAllOrdersByCustomerId(int customerId);
    boolean addOrder(Order order);
    boolean updateOrderTotal(int orderId);
}
