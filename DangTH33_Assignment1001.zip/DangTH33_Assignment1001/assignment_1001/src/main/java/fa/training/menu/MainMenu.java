package fa.training.menu;

import fa.training.dao.*;
import fa.training.entity.Customer;
import fa.training.entity.LineItem;
import fa.training.entity.Order;
import fa.training.services.CustomerService;
import fa.training.services.LineItemService;
import fa.training.services.OrderService;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainMenu {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws SQLException {
        CustomerDao customerDao = new CustomerDao();
        LineItemDao lineItemDao = new LineItemDao();
        ProductDao productDao = new ProductDao();
        OrdersDao ordersDao = new OrdersDao();
        totalPriceDao totalPriceDao = new totalPriceDao();
        int key;
        do {
            System.out.println("        =====Management System=====");
            System.out.println("System message: choose function that you want");
            System.out.println(" 1. Show list customer");
            System.out.println(" 2. View order by customerId");
            System.out.println(" 3. View lineItem by orderId");
            System.out.println(" 4. Get total price");
            System.out.println(" 5. Add more customers");
            System.out.println(" 6. Delete Customer by CustomerId");
            System.out.println(" 7. Update Customer by CustomerId");
            System.out.println(" 8. Add order");
            System.out.println(" 9. Add lineItem");
            System.out.println("10. Update order by orderId");
            System.out.println("11. Exit");
            key = sc.nextInt();
            switch (key) {
                case 1:
                    productDao.getAllCustomer();
                    break;
                case 2:
                    System.out.println("Enter the customerId to show list customer:");
                    sc.nextLine();
                    int id = sc.nextInt();
                    ordersDao.getAllOrdersByCustomerId(id);
                    break;
                case 3:
                    System.out.println("Enter lineItemId to access:");
                    int orderId1 = sc.nextInt();
                    lineItemDao.getAllItemsByOrderId(orderId1);
                    break;
                case 4:
                    System.out.println("Enter the orderId to access: ");
                    int orderId = sc.nextInt();
                    double price = 0;
                    price = totalPriceDao.computeOrderTotal(orderId);
                    System.out.println("Total price: " + price);
                    break;
                case 5:
                    Customer customer = new Customer();
                    CustomerService customerServes = new CustomerService();
                    customer = customerServes.createCustomer(customer);
                    customerDao.addCustomer(customer);
                    break;
                case 6:
                    customerDao.deleteCustomer();
                    break;
                case 7:
                    System.out.println("Update customerId update: ");
                    customerDao.updateCustomer();
                    break;
                case 8:
                    Order orders = new Order();
                    OrderService ordersServices = new OrderService();
                    orders = ordersServices.addOrder(orders);
                    ordersDao.addOrder(orders);
                    break;
                case 9:
                    LineItem lineItem = new LineItem();
                    LineItemService lineItemServices = new LineItemService();
                    lineItem = lineItemServices.createLineItem(lineItem);
                    lineItemDao.addLineItem(lineItem);
                    break;
                case 10:
                    System.out.println("Enter orderId that you wa update: ");
                    int orderId2 = sc.nextInt();
                    ordersDao.updateOrderTotal(orderId2);
                    break;
                case 11:
                    System.out.println("System message:The program closed!");
                    break;
            }
        } while (key < 11);

    }
}
