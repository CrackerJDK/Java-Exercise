package fa.training.connectdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDatabase {
    public static final String URL = "jdbc:sqlserver://localhost:1433;databaseName=Assignment1001JAVA";
    public static final String USER = "sa";
    public static final String PASSWORD = "0981141121me";

    public static void main(String[] args) throws SQLException {
        getConnection();
    }
    public static Connection getConnection() throws SQLException {

        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
