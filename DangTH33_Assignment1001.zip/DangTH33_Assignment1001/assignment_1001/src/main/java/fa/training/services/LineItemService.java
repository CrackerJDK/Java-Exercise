package fa.training.services;

import fa.training.entity.LineItem;

import java.util.Scanner;

public class LineItemService {
    public LineItem createLineItem(LineItem lineItems){
        Scanner input = new Scanner(System.in);
        boolean check = false;
        do {
            check = false;
            System.out.println("Enter orderId: ");
            try {
                lineItems.setOrderId(input.nextInt());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter productId: ");
            try {
                lineItems.setProductId(input.nextInt());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter the quantity that you want: ");
            try {
                lineItems.setQuantity(input.nextInt());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter the price of product: ");
            try {
                lineItems.setPrice(input.nextDouble());
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        return lineItems;
    }
}
