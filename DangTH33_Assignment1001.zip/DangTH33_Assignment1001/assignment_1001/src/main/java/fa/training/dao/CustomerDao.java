package fa.training.dao;

import fa.training.connectdb.ConnectDatabase;
import fa.training.entity.Customer;
import fa.training.intefaces.CustomerImp;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerDao implements CustomerImp {

    @Override
    public boolean addCustomer(Customer customer) {
        try(Connection connection = ConnectDatabase.getConnection()) {
            CallableStatement statement = connection.prepareCall("{call InsertCustomer(?, ?)}");
            statement.setInt("customerId",customer.getCustomerId());
            statement.setString("customerName",customer.getCustomerName());
            System.out.println("System message: The records inserted successfully");
            return statement.executeUpdate() > 0;
        } catch (SQLException throwables) {
            System.out.println("System message: The records can not insert, let's try again");
            throwables.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteCustomer() {
        try (Connection connection = ConnectDatabase.getConnection()) {
            Scanner input = new Scanner(System.in);
            CallableStatement statement = connection.prepareCall("{call DeleteCustomer(?)}");
            System.out.println("Enter the customerId: ");
            int customerId = input.nextInt();
            statement.setInt(1, customerId);
            System.out.println("System message: the records have been deleted");
            return statement.executeUpdate() > 0;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("System message: the records can not delete, let's try again");
        }
        return false;
    }

    @Override
    public boolean updateCustomer() {
        Scanner input = new Scanner(System.in);
        try (Connection connection = ConnectDatabase.getConnection()) {
            CallableStatement statement = connection.prepareCall("{call UpdateCustomer(?, ?)}");
            System.out.println("Enter the customerId: ");
            int customerId = input.nextInt();
            System.out.println("Enter the new customer's name: ");
            input.nextLine();
            String customerName = input.nextLine();
            statement.setInt(1, customerId);
            statement.setString(2,customerName);
            return statement.executeUpdate() > 0;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("System message: the records can not delete, let's try again");
        }
        return false;
    }
}

