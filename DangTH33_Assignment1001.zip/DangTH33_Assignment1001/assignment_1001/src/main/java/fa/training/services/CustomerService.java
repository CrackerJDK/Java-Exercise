package fa.training.services;

import fa.training.entity.Customer;

import java.util.Scanner;

public class CustomerService {
    public Customer createCustomer(Customer customer){
        Scanner sc = new Scanner(System.in);
        boolean check = false;
        do {
            check = false;
            System.out.println("Enter customerId: ");
            try {
                customer.setCustomerId(Integer.parseInt(sc.nextLine()));
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        do {
            check = false;
            System.out.println("Enter customer's name: ");
            try {
                customer.setCustomerName(String.valueOf(sc.nextLine()));
            }catch (Exception exception){
                check = true;
            }
        }while (check);

        return customer;
    }
}
