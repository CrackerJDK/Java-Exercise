package fa.training.intefaces;

import fa.training.entity.LineItem;
import java.sql.SQLException;
import java.util.List;

public interface LineItemImp {
    List<LineItem> getAllItemsByOrderId(int orderId);
    boolean addLineItem(LineItem item) throws SQLException;
}
