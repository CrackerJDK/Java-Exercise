package fa.training.dao;

import fa.training.connectdb.ConnectDatabase;
import fa.training.entity.LineItem;
import fa.training.intefaces.LineItemImp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LineItemDao implements LineItemImp {
    @Override
    public List<LineItem> getAllItemsByOrderId(int orderId) {
        List<LineItem> lineItems = new ArrayList<>();
        try(Connection connection = ConnectDatabase.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT orderId,productId,quantity,price FROM LineItem WHERE orderId = ?");
            System.out.println(orderId);
            preparedStatement.setInt(1,orderId);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()){
                int orderId1 = rs.getInt("orderId");
                int productId = rs.getInt("productId");
                int quantity = rs.getInt("quantity");
                double price = rs.getDouble("price");
                lineItems.add(new LineItem(orderId1,productId,quantity,price));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println(lineItems.toString());
        return lineItems;
    }

    @Override
    public boolean addLineItem(LineItem item) throws SQLException{
        Connection connection=null;
        try {
            connection = ConnectDatabase.getConnection();
            connection.setAutoCommit(false);
            PreparedStatement statement = connection.prepareStatement("INSERT INTO LineItem(orderId,productId,quantity,price) VALUES (? ,? ,? ,? )");
            statement.setInt(1,item.getOrderId());
            statement.setInt(2,item.getProductId());
            statement.setInt(3,item.getQuantity());
            statement.setDouble(4,item.getPrice());
            return statement.executeUpdate()> 0;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            if(Objects.nonNull(connection)){
                connection.rollback();
            }
            System.out.println("System message: the orders have been added into database!");
        }finally {
            assert connection != null;
            connection.close();
        }
        return false;
    }
}
