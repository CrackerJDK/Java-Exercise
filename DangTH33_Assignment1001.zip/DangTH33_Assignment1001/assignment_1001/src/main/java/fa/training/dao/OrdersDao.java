package fa.training.dao;

import fa.training.connectdb.ConnectDatabase;
import fa.training.entity.Order;
import fa.training.intefaces.OrderDaoImp;
import fa.training.services.OrderService;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrdersDao implements OrderDaoImp {

    @Override
    public List<Order> getAllOrdersByCustomerId(int customerId) {
        List<Order> ordersList = new ArrayList<>();
        try(Connection connection = ConnectDatabase.getConnection()) {
            String sqlQuery = "SELECT orderId,orderDate,customerId,employeeId,total FROM Orders WHERE customerId=? ";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1,customerId);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()){
                int orderId = rs.getInt("orderId");
                LocalDate orderDate =LocalDate.parse( rs.getString("orderDate"));
                int customerId1 = rs.getInt("customerId");
                int employeeId = rs.getInt("employeeId");
                int total = rs.getInt("total");
                ordersList.add(new Order(orderId,orderDate,customerId1,employeeId,total));
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println(ordersList.toString());
        return ordersList;
    }

    @Override
    public boolean addOrder(Order order) {
        try(Connection connection= ConnectDatabase.getConnection()) {
            String sqlQuery = "INSERT INTO Orders(orderId,orderDate,customerId,employeeId,total)  VALUES ( ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sqlQuery);
            statement.setInt(1,order.getOrderId());
            statement.setDate(2, java.sql.Date.valueOf(order.getOrderDate()));
            statement.setInt(3,order.getCustomerId());
            statement.setInt(4,order.getEmployeeId());
            statement.setDouble(5,order.getTotal());
            System.out.println("System message: the order has been added into database!!!");
            return statement.executeUpdate() > 0;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("System message: Something wrong with your values. Please check your values and try again!");
        }
        return false;
    }

    public Order checkUpdateOrder(Order orders, Order ordersDatabase){
        if (orders.getOrderDate() == null){
            orders.setOrderDate(ordersDatabase.getOrderDate());
        }
        else if (orders.getCustomerId() == 0){
            orders.setCustomerId(ordersDatabase.getCustomerId());
        }
        else if (orders.getEmployeeId() == 0){
            orders.setEmployeeId(ordersDatabase.getEmployeeId());
        }
        else if (orders.getTotal() == 0){
            orders.setTotal(ordersDatabase.getTotal());
        }
        else if (orders.getOrderId() == 0){
            orders.setOrderId(ordersDatabase.getOrderId());
        }
        return orders;
    }

    @Override
    public boolean updateOrderTotal(int orderId) {
        OrderService orderService= new OrderService();
        Order orders = new Order();
        Order ordersDatabase = new Order();
        ordersDatabase = getAllOrdersByCustomerIdNew(orderId,ordersDatabase);
        orders = orderService.updateOrders(orders);
        orders = checkUpdateOrder(orders,ordersDatabase);
        try(Connection connection=ConnectDatabase.getConnection()) {
            String sqlQuery = "UPDATE dbo.Orders SET orderDate=?, customerId=? ,employeeId = ? ,total=?  WHERE orderId=? ";
            PreparedStatement statement = connection.prepareStatement(sqlQuery);
            statement.setDate(1, java.sql.Date.valueOf(orders.getOrderDate()));
            statement.setInt(2,orders.getCustomerId());
            statement.setInt(3,orders.getEmployeeId());
            statement.setDouble(4,orders.getTotal());
            statement.setInt(5,orderId);
            System.out.println("System message: The database has been updated");
            return statement.executeUpdate() > 0;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("System message: the database can not update, you run into a problem. Let's check again!");
        }

        return false;
    }

    public Order getAllOrdersByCustomerIdNew(int customerId,Order orders) {
        try(Connection connection = ConnectDatabase.getConnection()) {
            String sqlQuery = "SELECT orderId,orderDate,customerId,employeeId,total FROM Orders WHERE orderId=? ";
            PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
            preparedStatement.setInt(1,customerId);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()){
                int orderId = rs.getInt("orderId");
                LocalDate order_date =LocalDate.parse( rs.getString("orderDate"));
                customerId = rs.getInt("customerId");
                int employeeId = rs.getInt("employeeId");
                int total = rs.getInt("total");
                orders.setEmployeeId(employeeId);
                orders.setOrderId(orderId);
                orders.setOrderDate(order_date);
                orders.setCustomerId(customerId);
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return orders;
    }

}
