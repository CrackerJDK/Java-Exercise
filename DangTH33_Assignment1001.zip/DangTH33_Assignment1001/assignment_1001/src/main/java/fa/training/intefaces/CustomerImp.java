package fa.training.intefaces;

import fa.training.entity.Customer;

public interface CustomerImp {
        boolean addCustomer(Customer customer);
        boolean deleteCustomer();
        boolean updateCustomer();
}
