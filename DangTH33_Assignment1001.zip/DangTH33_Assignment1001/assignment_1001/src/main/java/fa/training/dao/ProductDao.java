package fa.training.dao;

import fa.training.connectdb.ConnectDatabase;
import fa.training.entity.Customer;
import fa.training.intefaces.ProductImp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDao  implements ProductImp {
    @Override
    public List<Customer> getAllCustomer() {
        List<Customer> customerList = new ArrayList<>();
        try(Connection connection = ConnectDatabase.getConnection()) {
            String sqlQuery = "SELECT customerId,customerName FROM Customer";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sqlQuery);
            while (resultSet.next()){
                int customerId = resultSet.getInt("customerId");
                String customerName = resultSet.getString("customerName");
                customerList.add(new Customer(customerId, customerName));
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println(customerList.toString());
        return customerList;
    }

    @Override
    public List<Customer> createCustomer() {
        return null;
    }
}
