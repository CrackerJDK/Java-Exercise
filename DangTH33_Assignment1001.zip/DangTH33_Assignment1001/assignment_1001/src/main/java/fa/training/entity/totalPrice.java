package fa.training.entity;

public class totalPrice {
    private int orderId;
    private  double listPrice;

    public totalPrice(int orderId, double listPrice) {
        this.orderId = orderId;
        this.listPrice = listPrice;
    }

    public totalPrice() {

    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public double getListPrice() {
        return listPrice;
    }

    public void setListPrice(double listPrice) {
        this.listPrice = listPrice;
    }

    @Override
    public String toString() {
        return "totalPrice{" +
                "orderId=" + orderId +
                ", listPrice=" + listPrice +
                '}';
    }
}
