package fa.training.intefaces;

import fa.training.entity.Customer;

import java.util.List;

public interface ProductImp {
    List<Customer> getAllCustomer();
    List<Customer> createCustomer();
}
