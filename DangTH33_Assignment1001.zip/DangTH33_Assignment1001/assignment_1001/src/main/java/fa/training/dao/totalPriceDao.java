package fa.training.dao;

import fa.training.connectdb.ConnectDatabase;
import fa.training.entity.totalPrice;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class totalPriceDao {
    public  Double computeOrderTotal(int orderId) {
        totalPrice price = new totalPrice();
        double totalPrice = 0;
        try (Connection connection = ConnectDatabase.getConnection()) {
            String sqlQuery ="SELECT L.orderId, SUM(P.listPrice*L.quantity) AS totalPrice FROM Product P JOIN LineItem L ON L.productId = P.productId AND L.orderId=? GROUP BY L.orderId";
            PreparedStatement statement = connection.prepareStatement(sqlQuery);
            statement.setInt(1, orderId);
            ResultSet resultSet = statement.executeQuery();
            double customerId = 0;
            while (resultSet.next()){
                customerId = resultSet.getDouble(2);
            }
            return customerId;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return totalPrice;
    }
}
