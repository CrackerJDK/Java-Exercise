package Assignment701;

public class Sedan extends Car{
    private int length;

    public Sedan(int speed, double regularPrice, String color, int length) {
        super(speed, regularPrice, color);
        this.length = length;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public String toString() {
        return "Sedan{" +
                "speed: " + speed +
                ", Sale Price: " + getSalePrice() +
                ", color: " + color + '\'' +
                ", length: " + length +
                '}';
    }

    @Override
    public double getSalePrice() {
        if (this.length>20)
        {regularPrice*=0.95D;}
        else
        {regularPrice*=0.9D;}
        return regularPrice;
    }
}
