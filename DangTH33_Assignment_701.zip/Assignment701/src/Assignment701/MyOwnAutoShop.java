package Assignment701;

public class MyOwnAutoShop {
    public static void main(String[] args) {
        Sedan Mercedes = new Sedan(200, 100000, "Black", 14);
        Sedan BMWClassA = new Sedan(220, 150000, "Grey", 21);
        Sedan VolkswagenM2021 = new Sedan(220, 120000, "Emerald", 17);

        Ford Explorer = new Ford(250, 170000, "Blue", 2021, 3500);
        Ford Everest = new Ford(220, 100000, "White Smoke", 2020, 2000);
        Ford Ranger = new Ford(200, 55000, "Dark Grey", 2019, 3000);

        Truck Huyndai = new Truck(200, 75000, "Black", 2200);
        Truck Daewoo = new Truck(220, 60000, "Grey", 1800);
        Truck Mitsubishi = new Truck (220, 110000, "White", 2500);

        System.out.println("\n-----------------------------------------------------------------");
        System.out.println(Mercedes);
        System.out.println(BMWClassA);
        System.out.println(VolkswagenM2021);

        System.out.println("\n-----------------------------------------------------------------");
        System.out.println(Explorer);
        System.out.println(Everest);
        System.out.println(Ranger);

        System.out.println("\n-----------------------------------------------------------------");
        System.out.println(Huyndai);
        System.out.println(Daewoo);
        System.out.println(Mitsubishi);




    }
}
