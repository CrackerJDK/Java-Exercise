package customerManagement;

import com.sun.org.apache.xpath.internal.operations.Or;
import entity.Customer;
import entity.Order;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CustomerManagement {
    public static final List<Customer> customers = new ArrayList<>();
    public static Scanner sc = new Scanner(System.in);

    public static void addCustomer() throws ParseException, IOException {
        boolean runningLoops = true;
        do {
            System.out.println("------Enter Customer Information------");
            System.out.println("Customer name:");
            String name = sc.nextLine();
            System.out.println("Phone number: ");
            String phoneNumber = sc.nextLine();
            System.out.println("Address: ");
            String address = sc.nextLine();
            System.out.println("+ number: ");
            String number = sc.nextLine();
            System.out.println("+ date: ");
            SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            Date date = df.parse(sc.nextLine());

            customers.add(new Customer(name, phoneNumber, address, Collections.singletonList(new Order(number, date))));
            System.out.println("Do you want to add more customers?Y/N");
            String answer = sc.nextLine();
            if (answer.equalsIgnoreCase("Y"))
            {
                runningLoops = true;
            }
            else if (answer.equalsIgnoreCase("N"))
            {
                runningLoops = false;
            }
        }while (runningLoops);

        addToFile();
    }

    public static void showCustomer() {
        System.out.println(customers);
    }

    public static void addToFile() throws IOException {
        File file = new File("resource/customer.dat");
        try (ObjectOutputStream ois = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            for (Customer customer: customers){
                ois.writeObject(customer);
            }
        }
        System.out.println("System message: The customer has been added successfully.");
    }

    public static void searchOrderByCustomer() {
        System.out.println("Search by customer's phone number: ");
        String phoneNumber = sc.nextLine();
        for (Customer customer: customers)
        if (phoneNumber.equals(customer.getPhoneNumber()))
        {
            System.out.println(customer);
        }
    }

    public static void removeCustomer() {
        System.out.println("Search by customer's phone number: ");
        String phoneNumber = sc.nextLine();
        customers.removeIf(customer -> phoneNumber.equals(customer.getPhoneNumber()));
    }

    public static void menu() throws ParseException, IOException {
        boolean runningLoops = true;
        do {
            System.out.println("Choose function: ");
            System.out.println("1. Add a new customer");
            System.out.println("2. Show all customers");
            System.out.println("3. Search customer");
            System.out.println("4. Remove customer");
            System.out.println("5. Exit");

            int choice = Integer.parseInt(sc.nextLine());
            switch (choice) {
                case 1: addCustomer();
                break;
                case 2: showCustomer();
                break;
                case 3: searchOrderByCustomer();
                break;
                case 4: removeCustomer();
                break;
                case 5: System.out.println("System message: Program has been finished!");
                    runningLoops = false;
                break;
            }
        }while (runningLoops);

    }


}
